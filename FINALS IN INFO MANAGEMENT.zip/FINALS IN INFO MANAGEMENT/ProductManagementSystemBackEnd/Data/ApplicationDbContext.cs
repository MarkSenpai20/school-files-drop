﻿using Microsoft.EntityFrameworkCore;
using ProductManagement.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace ProductManagement.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure Product entity
            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.HasIndex(e => e.Barcode).IsUnique();
                entity.Property(e => e.Price).HasColumnType("decimal(18,2)");
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("GETDATE()");
            });

            // Seed data
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    Id = 1,
                    Name = "Sample Product 1",
                    Barcode = "1234567890123",
                    Price = 19.99m,
                    Description = "This is a sample product for testing",
                    Category = "Electronics",
                    Subcategory = "Accessories",
                    Shelf = "A1",
                    Quantity = 50,
                    CreatedDate = DateTime.Now
                },
                new Product
                {
                    Id = 2,
                    Name = "Sample Product 2",
                    Barcode = "9876543210987",
                    Price = 29.99m,
                    Description = "Another sample product",
                    Category = "Books",
                    Subcategory = "Fiction",
                    Shelf = "B2",
                    Quantity = 25,
                    CreatedDate = DateTime.Now
                }
            );
        }
    }
}