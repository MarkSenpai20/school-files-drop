using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProductManagementSystemBackEnd.Views
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
