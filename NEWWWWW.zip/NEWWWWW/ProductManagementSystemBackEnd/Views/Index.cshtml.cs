using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProductManagementSystemBackEnd.Views
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
