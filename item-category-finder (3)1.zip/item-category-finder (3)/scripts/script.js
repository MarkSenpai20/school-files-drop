// Import jQuery
const $ = window.$

$(document).ready(() => {
  // Initialize Data from localStorage or Set Defaults
  let categories = JSON.parse(localStorage.getItem("categories")) || []
  let subcategories = JSON.parse(localStorage.getItem("subcategories")) || []
  let shelves = JSON.parse(localStorage.getItem("shelves")) || []
  let products = JSON.parse(localStorage.getItem("products")) || []
  let shelfItems = JSON.parse(localStorage.getItem("shelfItems")) || []

  // Current product for modals
  let currentProductId = null

  // Utility Functions
  function saveData() {
    localStorage.setItem("categories", JSON.stringify(categories))
    localStorage.setItem("subcategories", JSON.stringify(subcategories))
    localStorage.setItem("shelves", JSON.stringify(shelves))
    localStorage.setItem("products", JSON.stringify(products))
    localStorage.setItem("shelfItems", JSON.stringify(shelfItems))
  }

  function generateId(array) {
    return array.length > 0 ? Math.max(...array.map((item) => item.id)) + 1 : 1
  }

  function populateSelect(selectId, options, valueKey, textKey) {
    const $select = window.$(selectId)
    $select.empty().append('<option value="">Select...</option>')
    options.forEach((option) => {
      $select.append(`<option value="${option[valueKey]}">${option[textKey]}</option>`)
    })
  }

  function showSection(sectionId) {
    window.$(".section").addClass("hidden")
    window.$("#dashboard").addClass("hidden")
    window.$(sectionId).removeClass("hidden")
  }

  function showToast(message, type = "info") {
    const $toast = window.$("#toast")
    $toast.text(message).removeClass("hidden success error warning info").addClass(type)

    setTimeout(() => {
      $toast.addClass("hidden")
    }, 3000)
  }

  function formatPrice(price) {
    return price ? `$${Number.parseFloat(price).toFixed(2)}` : "N/A"
  }

  // Initialize global search
  function initGlobalSearch() {
    // Populate category filter
    populateSelect("#search-category", categories, "id", "name")

    // Handle search input
    window.$("#global-search").on("input", function () {
      const searchTerm = window.$(this).val().trim().toLowerCase()
      const categoryId = Number.parseInt(window.$("#search-category").val()) || null

      if (searchTerm.length < 2) {
        window.$("#search-results").addClass("hidden")
        return
      }

      // Use Divide and Conquer search instead of linear search
      let results = divideAndConquerSearch(products, searchTerm)

      // Filter by category if selected
      if (categoryId) {
        results = results.filter((product) => {
          // Find shelf items with this product
          const productShelfItems = shelfItems.filter((item) => item.productId === product.id)

          // Check if any shelf item is in the selected category
          return productShelfItems.some((item) => {
            const shelf = shelves.find((s) => s.id === item.shelfId)
            if (!shelf) return false

            const sub = subcategories.find((s) => s.id === shelf.subcategoryId)
            if (!sub) return false

            return sub.categoryId === categoryId
          })
        })
      }

      // Display results
      displaySearchResults(results)
    })

    // Handle search button click
    window.$("#global-search-btn").click(() => {
      const searchTerm = window.$("#global-search").val().trim()
      if (searchTerm.length < 2) {
        showToast("Please enter at least 2 characters to search", "warning")
        return
      }

      // Trigger search
      window.$("#global-search").trigger("input")
    })

    // Handle category filter change
    window.$("#search-category").change(() => {
      window.$("#global-search").trigger("input")
    })

    // Close search results when clicking outside
    window.$(document).on("click", (e) => {
      if (!window.$(e.target).closest(".global-search-container").length) {
        window.$("#search-results").addClass("hidden")
      }
    })
  }

  function displaySearchResults(results) {
    const $results = window.$("#search-results")
    $results.empty()

    if (results.length === 0) {
      $results.append('<div class="search-result-item">No products found</div>')
      $results.removeClass("hidden")
      return
    }

    results.slice(0, 10).forEach((product) => {
      // Find locations
      const productLocations = getProductLocations(product.id)
      const locationText =
        productLocations.length > 0 ? `Found in ${productLocations.length} location(s)` : "Not on any shelf"

      $results.append(`
                <div class="search-result-item" data-id="${product.id}">
                    <div class="result-name">${product.name}</div>
                    <div class="result-details">
                        Barcode: ${product.barcode || "N/A"} | Price: ${formatPrice(product.price)}
                    </div>
                    <div class="result-location">
                        <i class="fas fa-map-marker-alt"></i> ${locationText}
                    </div>
                </div>
            `)
    })

    $results.removeClass("hidden")
  }

  // Get all locations for a product
  function getProductLocations(productId) {
    const locations = []

    // Find all shelf items with this product
    const productShelfItems = shelfItems.filter((item) => item.productId === productId)

    productShelfItems.forEach((item) => {
      const shelf = shelves.find((s) => s.id === item.shelfId)
      if (!shelf) return

      const subcategory = subcategories.find((s) => s.id === shelf.subcategoryId)
      if (!subcategory) return

      const category = categories.find((c) => c.id === subcategory.categoryId)
      if (!category) return

      locations.push({
        shelfId: shelf.id,
        shelfName: shelf.name,
        subcategoryId: subcategory.id,
        subcategoryName: subcategory.name,
        categoryId: category.id,
        categoryName: category.name,
        quantity: item.quantity,
        position: item.position || "Unknown", // Include position, default to "Unknown" for legacy data
      })
    })

    return locations
  }

  // Handle search result click
  window.$(document).on("click", ".search-result-item", function () {
    const productId = Number.parseInt(window.$(this).data("id"))
    showProductDetails(productId)
  })

  // Show product details modal
  function showProductDetails(productId) {
    const product = products.find((p) => p.id === productId)
    if (!product) return

    currentProductId = productId

    const $content = window.$("#product-details-content")
    $content.empty()

    // Build product details
    $content.append(`
            <div class="product-detail-row">
                <span class="product-detail-label">Name</span>
                <span class="product-detail-value">${product.name}</span>
            </div>
            <div class="product-detail-row">
                <span class="product-detail-label">Barcode</span>
                <span class="product-detail-value">${product.barcode || "N/A"}</span>
            </div>
            <div class="product-detail-row">
                <span class="product-detail-label">Price</span>
                <span class="product-detail-value">${formatPrice(product.price)}</span>
            </div>
        `)

    if (product.description) {
      $content.append(`
                <div class="product-detail-row">
                    <span class="product-detail-label">Description</span>
                    <span class="product-detail-value">${product.description}</span>
                </div>
            `)
    }

    // Count total quantity across all shelves
    const productShelfItems = shelfItems.filter((item) => item.productId === productId)
    const totalQuantity = productShelfItems.reduce((sum, item) => sum + item.quantity, 0)

    $content.append(`
            <div class="product-detail-row">
                <span class="product-detail-label">Total Quantity</span>
                <span class="product-detail-value">${totalQuantity} units across ${productShelfItems.length} location(s)</span>
            </div>
        `)

    // Show modal
    window.$("#product-details-modal").removeClass("hidden")
  }

  // Show product location modal
  function showProductLocation(productId) {
    const product = products.find((p) => p.id === productId)
    if (!product) return

    const locations = getProductLocations(productId)

    const $content = window.$("#product-location-content")
    $content.empty()

    $content.append(`<h4>${product.name} - Locations</h4>`)

    if (locations.length === 0) {
      $content.append("<p>This product is not currently on any shelf.</p>")
    } else {
      $content.append('<div class="product-locations-list"></div>')

      locations.forEach((location) => {
        window.$(".product-locations-list").append(`
                <div class="product-location-item">
                    <h4>${location.shelfName}</h4>
                    <div class="location-detail">
                        <span class="location-detail-label">Category:</span>
                        <span class="location-detail-value">${location.categoryName}</span>
                    </div>
                    <div class="location-detail">
                        <span class="location-detail-label">Subcategory:</span>
                        <span class="location-detail-value">${location.subcategoryName}</span>
                    </div>
                    <div class="location-detail">
                        <span class="location-detail-label">Quantity:</span>
                        <span class="location-detail-value">${location.quantity} units</span>
                    </div>
                    <div class="location-detail">
                        <span class="location-detail-label">Position:</span>
                        <span class="location-detail-value">${location.position}</span>
                    </div>
                    <button class="btn primary go-to-location" 
                        data-category="${location.categoryId}" 
                        data-subcategory="${location.subcategoryId}" 
                        data-shelf="${location.shelfId}">
                        <i class="fas fa-map-marker-alt"></i> Go to Location
                    </button>
                </div>
              `)
      })
    }

    // Show modal
    window.$("#product-location-modal").removeClass("hidden")
  }

  // Go to product location
  window.$(document).on("click", ".go-to-location", function () {
    const categoryId = Number.parseInt(window.$(this).data("category"))
    const subcategoryId = Number.parseInt(window.$(this).data("subcategory"))
    const shelfId = Number.parseInt(window.$(this).data("shelf"))

    // Close modals
    window.$(".modal").addClass("hidden")

    // Navigate to view items section
    showSection("#view-items-section")

    // Set selects
    window.$("#category-select").val(categoryId).trigger("change")

    // Need to wait for subcategory select to be populated
    setTimeout(() => {
      window.$("#subcategory-select").val(subcategoryId).trigger("change")

      // Need to wait for shelf select to be populated
      setTimeout(() => {
        window.$("#shelf-select").val(shelfId).trigger("change")
      }, 100)
    }, 100)
  })

  // View product location button
  window.$("#view-product-location").click(() => {
    window.$("#product-details-modal").addClass("hidden")
    showProductLocation(currentProductId)
  })

  // Close modals
  window.$(".close-modal").click(() => {
    window.$(".modal").addClass("hidden")
  })

  // Dashboard Navigation
  window.$("#view-items").click(() => {
    showSection("#view-items-section")
    populateSelect("#category-select", categories, "id", "name")
  })

  window.$("#add-item").click(() => {
    showSection("#add-item-section")
    populateSelect("#add-category-select", categories, "id", "name")
    window.$("#product-selector").addClass("hidden")
    window.$("#product-form").addClass("hidden")
    window.$("#scanner-container").addClass("hidden")
  })

  window.$("#manage-categories").click(() => {
    showSection("#manage-categories-section")
    displayCategories()
  })

  window.$("#manage-subcategories").click(() => {
    showSection("#manage-subcategories-section")
    populateSelect("#category-select-sub", categories, "id", "name")
  })

  window.$("#manage-shelves").click(() => {
    showSection("#manage-shelves-section")
    populateSelect("#category-select-shelf", categories, "id", "name")
  })

  window.$("#manage-products").click(() => {
    showSection("#manage-products-section")
    displayProducts()
  })

  window.$("#import-export").click(() => {
    showSection("#import-export-section")
  })

  window.$("[id^=back-to-dashboard]").click(() => {
    window.$(".section").addClass("hidden")
    window.$("#dashboard").removeClass("hidden")
  })

  // View Items Functionality
  window.$("#category-select").change(function () {
    const categoryId = Number.parseInt(window.$(this).val())
    const subs = subcategories.filter((sub) => sub.categoryId === categoryId)
    populateSelect("#subcategory-select", subs, "id", "name")
    window.$("#subcategory-select").prop("disabled", !subs.length)
    window.$("#shelf-select").prop("disabled", true).empty().append('<option value="">Select...</option>')
    window.$("#shelf-items").addClass("hidden")
  })

  window.$("#subcategory-select").change(function () {
    const subcategoryId = Number.parseInt(window.$(this).val())
    const shelfList = shelves.filter((shelf) => shelf.subcategoryId === subcategoryId)
    populateSelect("#shelf-select", shelfList, "id", "name")
    window.$("#shelf-select").prop("disabled", !shelfList.length)
    window.$("#shelf-items").addClass("hidden")
  })

  window.$("#shelf-select").change(function () {
    const shelfId = Number.parseInt(window.$(this).val())
    displayShelfItems(shelfId)
  })

  function displayShelfItems(shelfId) {
    const items = shelfItems.filter((item) => item.shelfId === shelfId)
    const $itemsList = window.$("#shelf-items-list").empty()

    if (items.length === 0) {
      $itemsList.append('<div class="empty-message">No items on this shelf.</div>')
    } else {
      // Sort items by position (which is based on ID)
      const sortedItems = [...items].sort((a, b) => a.id - b.id)

      sortedItems.forEach((item, index) => {
        const product = products.find((p) => p.id === item.productId)
        if (product) {
          $itemsList.append(`
                        <div class="item-card" data-id="${item.id}">
                            <h4>${product.name}</h4>
                            <p><strong>Barcode:</strong> ${product.barcode || "N/A"}</p>
                            <p><strong>Price:</strong> ${formatPrice(product.price)}</p>
                            <p><strong>Quantity:</strong> ${item.quantity}</p>
                            <p><strong>Position:</strong> ${index + 1} of ${sortedItems.length}</p>
                            <div class="item-actions">
                                <button class="btn danger remove-item" data-id="${item.id}">
                                    <i class="fas fa-trash"></i> Remove
                                </button>
                                <button class="btn primary edit-item-quantity" data-id="${item.id}">
                                    <i class="fas fa-edit"></i> Edit Qty
                                </button>
                                <button class="btn info view-product-details" data-product-id="${product.id}">
                                    <i class="fas fa-info-circle"></i> Details
                                </button>
                            </div>
                        </div>
                    `)
        }
      })
    }

    window.$("#shelf-items").removeClass("hidden")
  }

  // View product details from shelf item
  window.$(document).on("click", ".view-product-details", function () {
    const productId = Number.parseInt(window.$(this).data("product-id"))
    showProductDetails(productId)
  })

  // Search shelf items
  window.$("#shelf-items-search").on("input", function () {
    const searchTerm = window.$(this).val().toLowerCase()

    window.$(".item-card").each(function () {
      const itemId = Number.parseInt(window.$(this).data("id"))
      const item = shelfItems.find((i) => i.id === itemId)

      if (item) {
        const product = products.find((p) => p.id === item.productId)
        const productName = product ? product.name.toLowerCase() : ""
        const barcode = product ? (product.barcode || "").toLowerCase() : ""

        if (productName.includes(searchTerm) || barcode.includes(searchTerm)) {
          window.$(this).show()
        } else {
          window.$(this).hide()
        }
      }
    })
  })

  // Remove item from shelf
  window.$(document).on("click", ".remove-item", function () {
    const itemId = Number.parseInt(window.$(this).data("id"))
    const item = shelfItems.find((i) => i.id === itemId)

    if (item && confirm("Are you sure you want to remove this item from the shelf?")) {
      shelfItems = shelfItems.filter((i) => i.id !== itemId)
      saveData()

      const shelfId = Number.parseInt(window.$("#shelf-select").val())
      displayShelfItems(shelfId)

      showToast("Item removed from shelf", "success")
    }
  })

  // Edit item quantity
  window.$(document).on("click", ".edit-item-quantity", function () {
    const itemId = Number.parseInt(window.$(this).data("id"))
    const item = shelfItems.find((i) => i.id === itemId)

    if (item) {
      const product = products.find((p) => p.id === item.productId)
      const newQuantity = prompt(`Enter new quantity for ${product ? product.name : "item"}:`, item.quantity)

      if (newQuantity !== null) {
        const quantity = Number.parseInt(newQuantity)

        if (isNaN(quantity) || quantity < 1) {
          showToast("Please enter a valid quantity", "error")
          return
        }

        // Update the item quantity
        item.quantity = quantity
        saveData()

        const shelfId = Number.parseInt(window.$("#shelf-select").val())
        displayShelfItems(shelfId)

        showToast("Quantity updated", "success")
      }
    }
  })

  // Add Item to Shelf Functionality
  window.$("#add-category-select").change(function () {
    const categoryId = Number.parseInt(window.$(this).val())
    const subs = subcategories.filter((sub) => sub.categoryId === categoryId)
    populateSelect("#add-subcategory-select", subs, "id", "name")
    window.$("#add-subcategory-select").prop("disabled", !subs.length)
    window.$("#add-shelf-select").prop("disabled", true).empty().append('<option value="">Select...</option>')
  })

  window.$("#add-subcategory-select").change(function () {
    const subcategoryId = Number.parseInt(window.$(this).val())
    const shelfList = shelves.filter((shelf) => shelf.subcategoryId === subcategoryId)
    populateSelect("#add-shelf-select", shelfList, "id", "name")
    window.$("#add-shelf-select").prop("disabled", !shelfList.length)
  })

  // Select Existing Product
  window.$("#select-product").click(() => {
    if (!window.$("#add-shelf-select").val()) {
      showToast("Please select a shelf first", "warning")
      return
    }

    window.$("#product-selector").removeClass("hidden")
    window.$("#scanner-container").addClass("hidden")
    window.$("#product-form").addClass("hidden")

    // Populate product list
    displayProductSelector()
  })

  function displayProductSelector() {
    const $productsList = window.$("#products-list").empty()

    if (products.length === 0) {
      $productsList.append('<div class="empty-message">No products available. Add some first.</div>')
      return
    }

    products.forEach((product) => {
      $productsList.append(`
                <div class="product-item" data-id="${product.id}">
                    <strong>${product.name}</strong>
                    ${product.barcode ? `<br>Barcode: ${product.barcode}` : ""}
                    <br>Price: ${formatPrice(product.price)}
                </div>
            `)
    })
  }

  // Search products in selector
  window.$("#product-search").on("input", function () {
    const searchTerm = window.$(this).val().toLowerCase()

    window.$(".product-item").each(function () {
      const productId = Number.parseInt(window.$(this).data("id"))
      const product = products.find((p) => p.id === productId)

      if (product) {
        const productName = product.name.toLowerCase()
        const barcode = (product.barcode || "").toLowerCase()

        if (productName.includes(searchTerm) || barcode.includes(searchTerm)) {
          window.$(this).show()
        } else {
          window.$(this).hide()
        }
      }
    })
  })

  // Select product from list
  window.$(document).on("click", ".product-item", function () {
    const productId = Number.parseInt(window.$(this).data("id"))
    const product = products.find((p) => p.id === productId)

    if (product) {
      window.$("#product-selector").addClass("hidden")
      window.$("#product-form").removeClass("hidden")

      window.$("#product-barcode").val(product.barcode || "")
      window.$("#product-name").val(product.name)
      window.$("#product-price").val(product.price || "")
      window.$("#product-description").val(product.description || "")
      window.$("#product-quantity").val(1)

      // Store the product ID for later use
      window.$("#save-product").data("product-id", product.id)
    }
  })

  // Add new product button
  window.$("#add-new-product").click(() => {
    if (!window.$("#add-shelf-select").val()) {
      showToast("Please select a shelf first", "warning")
      return
    }

    window.$("#product-form").removeClass("hidden")
    window.$("#scanner-container").addClass("hidden")
    window.$("#product-selector").addClass("hidden")

    // Clear form
    window.$("#product-barcode").val("")
    window.$("#product-name").val("")
    window.$("#product-price").val("")
    window.$("#product-description").val("")
    window.$("#product-quantity").val(1)

    // Clear product ID
    window.$("#save-product").data("product-id", "")
  })

  // Save Product to Shelf
  window.$("#save-product").click(function () {
    const shelfId = Number.parseInt(window.$("#add-shelf-select").val())
    const productId = window.$(this).data("product-id")
    const barcode = window.$("#product-barcode").val().trim()
    const name = window.$("#product-name").val().trim()
    const price = window.$("#product-price").val().trim()
    const description = window.$("#product-description").val().trim()
    const quantity = Number.parseInt(window.$("#product-quantity").val())

    if (!shelfId) {
      showToast("Please select a shelf", "warning")
      return
    }

    if (!name) {
      showToast("Please enter a product name", "warning")
      return
    }

    if (!quantity || quantity < 1) {
      showToast("Please enter a valid quantity", "warning")
      return
    }

    // Check if barcode already exists for a different product
    if (barcode && productId === "" && products.some((p) => p.barcode === barcode)) {
      showToast(`A product with barcode ${barcode} already exists`, "error")
      return
    }

    let finalProductId

    // If product ID exists, use it, otherwise create a new product
    if (productId) {
      finalProductId = Number.parseInt(productId)

      // Update existing product if needed
      const existingProduct = products.find((p) => p.id === finalProductId)
      if (existingProduct) {
        // Only update if something changed
        if (
          existingProduct.name !== name ||
          existingProduct.barcode !== barcode ||
          existingProduct.price !== price ||
          existingProduct.description !== description
        ) {
          existingProduct.name = name
          existingProduct.barcode = barcode || null
          existingProduct.price = price || null
          existingProduct.description = description || null
        }
      }
    } else {
      // Create new product
      const newProduct = {
        id: generateId(products),
        name,
        barcode: barcode || null,
        price: price || null,
        description: description || null,
      }

      products.push(newProduct)
      finalProductId = newProduct.id
    }

    // Calculate position - count existing items on this shelf + 1
    const itemsOnShelf = shelfItems.filter((item) => item.shelfId === shelfId)
    const position = itemsOnShelf.length + 1

    // Add item to shelf with position
    const newShelfItem = {
      id: generateId(shelfItems),
      shelfId,
      productId: finalProductId,
      quantity,
      position, // Add position property
    }

    shelfItems.push(newShelfItem)
    saveData()

    // Reset form
    window.$("#product-form").addClass("hidden")
    window.$("#product-barcode, #product-name, #product-price, #product-description").val("")
    window.$("#product-quantity").val(1)
    window.$("#save-product").data("product-id", "")

    showToast("Product added to shelf successfully!", "success")
  })

  // Manage Categories
  function displayCategories() {
    const $list = window.$("#category-list").empty()
    if (categories.length === 0) {
      $list.append('<li class="empty-list">No categories found. Add one below.</li>')
      return
    }

    categories.forEach((cat) => {
      const subCount = subcategories.filter((sub) => sub.categoryId === cat.id).length
      $list.append(`
                <li>
                    <span>${cat.name} <small>(${subCount} subcategories)</small></span>
                    <button class="btn danger delete-btn delete-category" data-id="${cat.id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </li>
            `)
    })
  }

  window.$("#add-category").click(() => {
    const name = window.$("#new-category-name").val().trim()
    if (name) {
      categories.push({ id: generateId(categories), name })
      saveData()
      displayCategories()
      window.$("#new-category-name").val("")
      showToast("Category added successfully", "success")
    } else {
      showToast("Please enter a category name", "warning")
    }
  })

  window.$(document).on("click", ".delete-category", function () {
    const id = Number.parseInt(window.$(this).data("id"))
    const catName = categories.find((cat) => cat.id === id)?.name || "Unknown"

    if (
      confirm(
        `Are you sure you want to delete the category "${catName}"? This will also delete all related subcategories and shelves.`,
      )
    ) {
      // Find affected subcategories
      const affectedSubcategories = subcategories.filter((sub) => sub.categoryId === id)
      const affectedSubcategoryIds = affectedSubcategories.map((sub) => sub.id)

      // Find affected shelves
      const affectedShelves = shelves.filter((shelf) => affectedSubcategoryIds.includes(shelf.subcategoryId))
      const affectedShelfIds = affectedShelves.map((shelf) => shelf.id)

      // Remove shelf items
      shelfItems = shelfItems.filter((item) => !affectedShelfIds.includes(item.shelfId))

      // Remove the category, subcategories, and shelves
      categories = categories.filter((cat) => cat.id !== id)
      subcategories = subcategories.filter((sub) => sub.categoryId !== id)
      shelves = shelves.filter((shelf) => !affectedSubcategoryIds.includes(shelf.subcategoryId))

      saveData()
      displayCategories()
      showToast(`Category "${catName}" deleted`, "success")
    }
  })

  // Manage Subcategories
  window.$("#category-select-sub").change(function () {
    const categoryId = Number.parseInt(window.$(this).val())
    displaySubcategories(categoryId)
  })

  function displaySubcategories(categoryId) {
    const subs = subcategories.filter((sub) => sub.categoryId === categoryId)
    const $list = window.$("#subcategory-list").empty()

    if (subs.length === 0) {
      $list.append('<li class="empty-list">No subcategories found. Add one below.</li>')
      return
    }

    subs.forEach((sub) => {
      const shelfCount = shelves.filter((shelf) => shelf.subcategoryId === sub.id).length
      $list.append(`
                <li>
                    <span>${sub.name} <small>(${shelfCount} shelves)</small></span>
                    <button class="btn danger delete-btn delete-subcategory" data-id="${sub.id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </li>
            `)
    })
  }

  window.$("#add-subcategory").click(() => {
    const categoryId = Number.parseInt(window.$("#category-select-sub").val())
    const name = window.$("#new-subcategory-name").val().trim()

    if (!categoryId) {
      showToast("Please select a category", "warning")
      return
    }

    if (!name) {
      showToast("Please enter a subcategory name", "warning")
      return
    }

    subcategories.push({ id: generateId(subcategories), categoryId, name })
    saveData()
    window.$("#new-subcategory-name").val("")
    displaySubcategories(categoryId)
    showToast("Subcategory added successfully", "success")
  })

  window.$(document).on("click", ".delete-subcategory", function () {
    const id = Number.parseInt(window.$(this).data("id"))
    const subName = subcategories.find((sub) => sub.id === id)?.name || "Unknown"

    if (
      confirm(
        `Are you sure you want to delete the subcategory "${subName}"? This will also delete all related shelves.`,
      )
    ) {
      const categoryId = subcategories.find((sub) => sub.id === id)?.categoryId

      // Find affected shelves
      const affectedShelves = shelves.filter((shelf) => shelf.subcategoryId === id)
      const affectedShelfIds = affectedShelves.map((shelf) => shelf.id)

      // Remove shelf items
      shelfItems = shelfItems.filter((item) => !affectedShelfIds.includes(item.shelfId))

      // Remove the subcategory and shelves
      subcategories = subcategories.filter((sub) => sub.id !== id)
      shelves = shelves.filter((shelf) => shelf.subcategoryId !== id)

      saveData()
      if (categoryId) displaySubcategories(categoryId)
      showToast(`Subcategory "${subName}" deleted`, "success")
    }
  })

  // Manage Shelves
  window.$("#category-select-shelf").change(function () {
    const categoryId = Number.parseInt(window.$(this).val())
    const subs = subcategories.filter((sub) => sub.categoryId === categoryId)
    populateSelect("#subcategory-select-shelf", subs, "id", "name")
    window.$("#subcategory-select-shelf").prop("disabled", !subs.length)
    window.$("#shelf-list").empty()
  })

  window.$("#subcategory-select-shelf").change(function () {
    const subcategoryId = Number.parseInt(window.$(this).val())
    displayShelves(subcategoryId)
  })

  function displayShelves(subcategoryId) {
    const shelfList = shelves.filter((shelf) => shelf.subcategoryId === subcategoryId)
    const $list = window.$("#shelf-list").empty()

    if (shelfList.length === 0) {
      $list.append('<li class="empty-list">No shelves found. Add one below.</li>')
      return
    }

    shelfList.forEach((shelf) => {
      // Count items on this shelf
      const itemsOnShelf = shelfItems.filter((item) => item.shelfId === shelf.id)
      const itemCount = itemsOnShelf.length
      const totalQuantity = itemsOnShelf.reduce((sum, item) => sum + item.quantity, 0)

      $list.append(`
                <li>
                    <span>${shelf.name} - Capacity: ${shelf.capacity} (${itemCount} products, ${totalQuantity} items)</span>
                    <button class="btn danger delete-btn delete-shelf" data-id="${shelf.id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </li>
            `)
    })
  }

  window.$("#add-shelf").click(() => {
    const subcategoryId = Number.parseInt(window.$("#subcategory-select-shelf").val())
    const name = window.$("#new-shelf-name").val().trim()
    const capacity = Number.parseInt(window.$("#new-shelf-capacity").val())

    if (!subcategoryId) {
      showToast("Please select a subcategory", "warning")
      return
    }

    if (!name) {
      showToast("Please enter a shelf name", "warning")
      return
    }

    if (!capacity || capacity <= 0) {
      showToast("Please enter a valid capacity", "warning")
      return
    }

    shelves.push({
      id: generateId(shelves),
      subcategoryId,
      name,
      capacity,
    })

    saveData()
    window.$("#new-shelf-name, #new-shelf-capacity").val("")
    displayShelves(subcategoryId)
    showToast("Shelf added successfully", "success")
  })

  window.$(document).on("click", ".delete-shelf", function () {
    const id = Number.parseInt(window.$(this).data("id"))
    const shelf = shelves.find((s) => s.id === id)

    if (!shelf) return

    const itemsOnShelf = shelfItems.filter((item) => item.shelfId === id)

    let message = `Are you sure you want to delete the shelf "${shelf.name}"?`
    if (itemsOnShelf.length > 0) {
      message += ` This shelf contains ${itemsOnShelf.length} products.`
    }

    if (confirm(message)) {
      const subcategoryId = shelf.subcategoryId

      // Remove items from this shelf
      shelfItems = shelfItems.filter((item) => item.shelfId !== id)

      // Remove the shelf
      shelves = shelves.filter((s) => s.id !== id)

      saveData()
      displayShelves(subcategoryId)
      showToast(`Shelf "${shelf.name}" deleted`, "success")
    }
  })

  // Manage Products
  function displayProducts() {
    const $tableBody = window.$("#products-table-body").empty()

    if (products.length === 0) {
      $tableBody.append(`
                <tr>
                    <td colspan="4" class="text-center">No products found. Add some first.</td>
                </tr>
            `)
      return
    }

    products.forEach((product) => {
      $tableBody.append(`
                <tr>
                    <td>${product.barcode || "N/A"}</td>
                    <td>${product.name}</td>
                    <td>${formatPrice(product.price)}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn primary edit-product-btn" data-id="${product.id}">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="btn danger delete-product" data-id="${product.id}">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                            <button class="btn info view-product-details-btn" data-id="${product.id}">
                                <i class="fas fa-info-circle"></i> Details
                            </button>
                        </div>
                    </td>
                </tr>
            `)
    })
  }

  // View product details from product management
  window.$(document).on("click", ".view-product-details-btn", function () {
    const productId = Number.parseInt(window.$(this).data("id"))
    showProductDetails(productId)
  })

  // Search products in management
  window.$("#manage-product-search").on("input", function () {
    const searchTerm = window.$(this).val().toLowerCase()

    window.$("#products-table-body tr").each(function () {
      const $row = window.$(this)
      const barcode = $row.find("td:first-child").text().toLowerCase()
      const name = $row.find("td:nth-child(2)").text().toLowerCase()

      if (barcode.includes(searchTerm) || name.includes(searchTerm)) {
        $row.show()
      } else {
        $row.hide()
      }
    })
  })

  // Add new product button
  window.$("#add-product-btn").click(() => {
    // Clear form
    window.$("#edit-product-barcode").val("")
    window.$("#edit-product-name").val("")
    window.$("#edit-product-price").val("")
    window.$("#edit-product-description").val("")

    // Set modal title
    window.$(".modal-header h3").text("Add New Product")

    // Show modal
    window.$("#edit-product-modal").removeClass("hidden")

    // Set update button data
    window.$("#update-product").data("product-id", "")
  })

  // Edit product - Fixed to properly show the modal
  window.$(document).on("click", ".edit-product-btn", function () {
    const productId = Number.parseInt(window.$(this).data("id"))
    const product = products.find((p) => p.id === productId)

    if (product) {
      // Fill form
      window.$("#edit-product-barcode").val(product.barcode || "")
      window.$("#edit-product-name").val(product.name)
      window.$("#edit-product-price").val(product.price || "")
      window.$("#edit-product-description").val(product.description || "")

      // Set modal title
      window.$(".modal-header h3").text("Edit Product")

      // Show modal
      window.$("#edit-product-modal").removeClass("hidden")

      // Set update button data
      window.$("#update-product").data("product-id", productId)
    }
  })

  // Close modal
  window.$("#close-edit-modal, #cancel-edit").click(() => {
    window.$("#edit-product-modal").addClass("hidden")
  })

  // Update product
  window.$("#update-product").click(function () {
    const productId = window.$(this).data("product-id")
    const barcode = window.$("#edit-product-barcode").val().trim()
    const name = window.$("#edit-product-name").val().trim()
    const price = window.$("#edit-product-price").val().trim()
    const description = window.$("#edit-product-description").val().trim()

    if (!name) {
      showToast("Please enter a product name", "warning")
      return
    }

    // Check if barcode already exists for a different product
    if (barcode && products.some((p) => p.barcode === barcode && p.id !== productId)) {
      showToast(`A product with barcode ${barcode} already exists`, "error")
      return
    }

    if (productId) {
      // Update existing product
      const product = products.find((p) => p.id === productId)
      if (product) {
        product.name = name
        product.barcode = barcode || null
        product.price = price || null
        product.description = description || null

        saveData()
        displayProducts()
        window.$("#edit-product-modal").addClass("hidden")
        showToast("Product updated successfully", "success")
      }
    } else {
      // Add new product
      const newProduct = {
        id: generateId(products),
        name,
        barcode: barcode || null,
        price: price || null,
        description: description || null,
      }

      products.push(newProduct)
      saveData()
      displayProducts()
      window.$("#edit-product-modal").addClass("hidden")
      showToast("Product added successfully", "success")
    }
  })

  // Delete product
  window.$(document).on("click", ".delete-product", function () {
    const productId = Number.parseInt(window.$(this).data("id"))
    const product = products.find((p) => p.id === productId)

    if (product && confirm(`Are you sure you want to delete the product "${product.name}"?`)) {
      // Check if product is on any shelves
      const itemsWithProduct = shelfItems.filter((item) => item.productId === productId)

      if (itemsWithProduct.length > 0) {
        // Remove product from shelves
        shelfItems = shelfItems.filter((item) => item.productId !== productId)
        showToast(`Product removed from ${itemsWithProduct.length} shelf locations`, "info")
      }

      // Remove the product
      products = products.filter((p) => p.id !== productId)
      saveData()
      displayProducts()
      showToast(`Product "${product.name}" deleted`, "success")
    }
  })

  // Import/Export Functionality
  window.$("#export-data").click(() => {
    const exportData = {}

    if (window.$("#export-products").is(":checked")) {
      exportData.products = products
    }

    if (window.$("#export-categories").is(":checked")) {
      exportData.categories = categories
    }

    if (window.$("#export-subcategories").is(":checked")) {
      exportData.subcategories = subcategories
    }

    if (window.$("#export-shelves").is(":checked")) {
      exportData.shelves = shelves
    }

    if (window.$("#export-shelf-items").is(":checked")) {
      exportData.shelfItems = shelfItems
    }

    // Create JSON file
    const dataStr = JSON.stringify(exportData, null, 2)
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr)

    // Create download link
    const exportFileDefaultName = "inventory_data_" + new Date().toISOString().slice(0, 10) + ".json"

    const linkElement = document.createElement("a")
    linkElement.setAttribute("href", dataUri)
    linkElement.setAttribute("download", exportFileDefaultName)
    linkElement.click()

    showToast("Data exported successfully", "success")
  })

  // Enable import button when file selected
  window.$("#import-file").change(function () {
    window.$("#import-data").prop("disabled", !window.$(this).val())
  })

  // Import data
  window.$("#import-data").click(() => {
    const fileInput = document.getElementById("import-file")
    const file = fileInput.files[0]

    if (!file) {
      showToast("Please select a file to import", "warning")
      return
    }

    const reader = new FileReader()

    reader.onload = (e) => {
      try {
        const importData = JSON.parse(e.target.result)
        const importMode = window.$('input[name="import-mode"]:checked').val()

        if (importMode === "replace") {
          // Replace all data
          if (importData.products) products = importData.products
          if (importData.categories) categories = importData.categories
          if (importData.subcategories) subcategories = importData.subcategories
          if (importData.shelves) shelves = importData.shelves
          if (importData.shelfItems) shelfItems = importData.shelfItems
        } else {
          // Merge data
          if (importData.products) {
            // Merge products by barcode or create new ones
            importData.products.forEach((importProduct) => {
              const existingProduct = importProduct.barcode
                ? products.find((p) => p.barcode === importProduct.barcode)
                : null

              if (existingProduct) {
                // Update existing product
                existingProduct.name = importProduct.name
                existingProduct.price = importProduct.price
                existingProduct.description = importProduct.description
              } else {
                // Add new product with new ID
                const newProduct = {
                  ...importProduct,
                  id: generateId(products),
                }
                products.push(newProduct)
              }
            })
          }

          if (importData.categories) {
            // Merge categories by name
            importData.categories.forEach((importCategory) => {
              if (!categories.some((c) => c.name === importCategory.name)) {
                categories.push({
                  ...importCategory,
                  id: generateId(categories),
                })
              }
            })
          }

          if (importData.subcategories) {
            // Merge subcategories
            importData.subcategories.forEach((importSubcategory) => {
              if (
                !subcategories.some(
                  (s) => s.name === importSubcategory.name && s.categoryId === importSubcategory.categoryId,
                )
              ) {
                subcategories.push({
                  ...importSubcategory,
                  id: generateId(subcategories),
                })
              }
            })
          }

          if (importData.shelves) {
            // Merge shelves
            importData.shelves.forEach((importShelf) => {
              if (!shelves.some((s) => s.name === importShelf.name && s.subcategoryId === importShelf.subcategoryId)) {
                shelves.push({
                  ...importShelf,
                  id: generateId(shelves),
                })
              }
            })
          }

          // Shelf items are more complex to merge, so we'll skip them in merge mode
        }

        saveData()
        showToast("Data imported successfully", "success")

        // Reset file input
        fileInput.value = ""
        window.$("#import-data").prop("disabled", true)
      } catch (error) {
        showToast("Error importing data: " + error.message, "error")
      }
    }

    reader.readAsText(file)
  })

  // Initialize the app with some sample data if empty
  function initializeWithSampleData() {
    if (categories.length === 0 && products.length === 0) {
      // Sample categories
      categories = [
        { id: 1, name: "Snacks" },
        { id: 2, name: "Beverages" },
        { id: 3, name: "Canned Goods" },
      ]

      // Sample subcategories
      subcategories = [
        { id: 1, categoryId: 1, name: "Chips" },
        { id: 2, categoryId: 1, name: "Cookies" },
        { id: 3, categoryId: 2, name: "Soda" },
        { id: 4, categoryId: 2, name: "Juice" },
        { id: 5, categoryId: 3, name: "Vegetables" },
      ]

      // Sample shelves
      shelves = [
        { id: 1, subcategoryId: 1, name: "Top Shelf", capacity: 50 },
        { id: 2, subcategoryId: 1, name: "Middle Shelf", capacity: 40 },
        { id: 3, subcategoryId: 2, name: "Bottom Shelf", capacity: 30 },
        { id: 4, subcategoryId: 3, name: "Refrigerated Section", capacity: 60 },
        { id: 5, subcategoryId: 4, name: "Display Case", capacity: 25 },
      ]

      // Sample products
      products = [
        {
          id: 1,
          name: "Oishi Prawn Crackers",
          barcode: "4800194151000",
          price: 1.99,
          description: "Crispy prawn-flavored crackers",
        },
        {
          id: 2,
          name: "Oishi Potato Chips",
          barcode: "4800194152000",
          price: 2.49,
          description: "Classic potato chips",
        },
        { id: 3, name: "Coca-Cola", barcode: "5449000000996", price: 1.29, description: "Classic cola drink" },
        {
          id: 4,
          name: "Oreo Cookies",
          barcode: "7622300335823",
          price: 3.99,
          description: "Chocolate sandwich cookies",
        },
        { id: 5, name: "Del Monte Corn", barcode: "24000141822", price: 1.79, description: "Canned sweet corn" },
      ]

      // Sample shelf items with positions
      shelfItems = [
        { id: 1, shelfId: 1, productId: 1, quantity: 10, position: 1 },
        { id: 2, shelfId: 1, productId: 2, quantity: 15, position: 2 },
        { id: 3, shelfId: 4, productId: 3, quantity: 24, position: 1 },
        { id: 4, shelfId: 3, productId: 4, quantity: 12, position: 1 },
        { id: 5, shelfId: 5, productId: 5, quantity: 8, position: 1 },
      ]

      saveData()
      showToast("Sample data loaded", "info")
    }
  }

  // Add the Divide and Conquer search function after the initGlobalSearch function
  function divideAndConquerSearch(items, searchTerm) {
    // If the array is empty or has only one element
    if (items.length <= 1) {
      // Check if the single item matches
      if (items.length === 1) {
        const item = items[0]
        const nameMatch = item.name.toLowerCase().includes(searchTerm)
        const barcodeMatch = item.barcode && item.barcode.toLowerCase().includes(searchTerm)
        return nameMatch || barcodeMatch ? [item] : []
      }
      return []
    }

    // Divide the array into two halves
    const mid = Math.floor(items.length / 2)
    const leftHalf = items.slice(0, mid)
    const rightHalf = items.slice(mid)

    // Recursively search both halves
    const leftResults = divideAndConquerSearch(leftHalf, searchTerm)
    const rightResults = divideAndConquerSearch(rightHalf, searchTerm)

    // Combine the results
    return [...leftResults, ...rightResults]
  }

  // Add an optimized binary search function for exact ID matches
  function binarySearchById(items, id) {
    // First, ensure the array is sorted by id
    const sortedItems = [...items].sort((a, b) => a.id - b.id)

    let left = 0
    let right = sortedItems.length - 1

    while (left <= right) {
      const mid = Math.floor((left + right) / 2)

      if (sortedItems[mid].id === id) {
        return sortedItems[mid]
      }

      if (sortedItems[mid].id < id) {
        left = mid + 1
      } else {
        right = mid - 1
      }
    }

    return null // Not found
  }

  // Add a function to search products by ID using binary search
  function findProductById(productId) {
    return binarySearchById(products, productId)
  }

  // Initialize the app
  initGlobalSearch()
  initializeWithSampleData()
})
